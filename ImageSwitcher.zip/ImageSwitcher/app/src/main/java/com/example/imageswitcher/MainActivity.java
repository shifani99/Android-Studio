package com.example.imageswitcher;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ViewSwitcher;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ImageSwitcher imageSwitcher;
    Button next;
    ArrayList<Integer> images;
    int position = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        images = new ArrayList<>();
        images.add(R.drawable.dhoni);
        images.add(R.drawable.mayank);
        images.add(R.drawable.pandya);
        images.add(R.drawable.pant);
        images.add(R.drawable.virat);

        imageSwitcher = findViewById(R.id.imageSwitcher);
        next = findViewById(R.id.next);

        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView image = new ImageView(getApplicationContext());
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                image.setLayoutParams(new ImageSwitcher.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));
                return image;
            }
        });
        imageSwitcher.setImageResource(images.get(position));

        Animation in = AnimationUtils.loadAnimation(getApplicationContext(),android.R.anim.fade_in);
        Animation out = AnimationUtils.loadAnimation(getApplicationContext(),android.R.anim.fade_out);

        imageSwitcher.setInAnimation(in);
        imageSwitcher.setOutAnimation(out);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                position++;
                if(position==images.size())
                    position=0;
                imageSwitcher.setImageResource(images.get(position));
            }
        });
    }
}