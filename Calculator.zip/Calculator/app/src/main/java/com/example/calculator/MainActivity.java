package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import org.mariuszgromada.math.mxparser.*;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String exp;
    TextView calc;
    Button cancel, del, mod, div, one,two, three, four, five, six,seven, eight,nine,zero, mul, sub, add, dot, equal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calc = findViewById(R.id.calc);
        cancel = findViewById(R.id.cancel);
        del = findViewById(R.id.del);
        mod = findViewById(R.id.mod);
        div = findViewById(R.id.div);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        zero = findViewById(R.id.zero);
        mul = findViewById(R.id.mul);
        sub = findViewById(R.id.sub);
        add = findViewById(R.id.add);
        dot = findViewById(R.id.dot);
        equal = findViewById(R.id.equal);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.zero:
                        calc.append("0");
                        break;
                    case R.id.one:
                        calc.append("1");
                        break;
                    case R.id.two:
                        calc.append("2");
                        break;
                    case R.id.three:
                        calc.append("3");
                        break;
                    case R.id.four:
                        calc.append("4");
                        break;
                    case R.id.five:
                        calc.append("5");
                        break;
                    case R.id.six:
                        calc.append("6");
                        break;
                    case R.id.seven:
                        calc.append("7");
                        break;
                    case R.id.eight:
                        calc.append("8");
                        break;
                    case R.id.nine:
                        calc.append("9");
                        break;
                    case R.id.sub:
                        calc.append(" - ");
                        break;
                    case R.id.add:
                        calc.append(" + ");
                        break;
                    case R.id.mul:
                        calc.append(" * ");
                        break;
                    case R.id.div:
                        calc.append(" / ");
                        break;
                    case R.id.dot:
                        calc.append(".");
                        break;
                    case R.id.mod:
                        calc.append(" % ");
                        break;
                    case R.id.cancel:
                        calc.setText(" ");
                        break;
                    case R.id.del:
                        String temp = calc.getText().toString();
                        temp = temp.substring(0,temp.length()-1);
                        calc.setText(temp);
                        break;
                    case R.id.equal:
                        exp = calc.getText().toString();
                        Expression e = new Expression(exp);
                        exp = String.valueOf(e.calculate());
                        calc.setText(exp);
                        break;
                }
            }
        };

        add.setOnClickListener(listener);
        sub.setOnClickListener(listener);
        mul.setOnClickListener(listener);
        div.setOnClickListener(listener);
        mod.setOnClickListener(listener);
        dot.setOnClickListener(listener);
        equal.setOnClickListener(listener);
        one.setOnClickListener(listener);
        two.setOnClickListener(listener);
        three.setOnClickListener(listener);
        four.setOnClickListener(listener);
        five.setOnClickListener(listener);
        six.setOnClickListener(listener);
        seven.setOnClickListener(listener);
        eight.setOnClickListener(listener);
        nine.setOnClickListener(listener);
        zero.setOnClickListener(listener);
        cancel.setOnClickListener(listener);
        del.setOnClickListener(listener);
    }
}