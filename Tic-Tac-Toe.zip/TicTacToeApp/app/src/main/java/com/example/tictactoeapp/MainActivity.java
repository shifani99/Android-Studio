package com.example.tictactoeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView A1, B1, C1, A2, A3, B2, B3, C2, C3;
    TextView score1, score2;
    int turn, bit, sc1, sc2;
    int[][] board;
    String X, O, XO;
    Context c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c=getApplicationContext();

        A1 = findViewById(R.id.A1);
        A2 = findViewById(R.id.A2);
        A3 = findViewById(R.id.A3);
        B1 = findViewById(R.id.B1);
        B2 = findViewById(R.id.B2);
        B3 = findViewById(R.id.B3);
        C1 = findViewById(R.id.C1);
        C2 = findViewById(R.id.C2);
        C3 = findViewById(R.id.C3);
        score1 = findViewById(R.id.score1);
        score2 = findViewById(R.id.score2);

        turn = 0;
        sc1=0;
        sc2=0;
        board = new int[3][3];
//        empty=" ";
        bit=2;
        XO = "X";
        X="X";
        O="O";

        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                board[i][j]=0;
            }
        }

        View.OnClickListener listener = new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                System.out.println(v.getId());

                System.out.println(R.id.A1);
                System.out.println(A1.getText().toString());

                if (turn % 2 == 0) {
                    bit = 2;
                    XO = "X";
                } else {
                    bit = 1;
                    XO = "O";
                }

                switch (v.getId()) {
                    case R.id.A1:
                        System.out.println("A1");
//                        score1.setText("A1");
                        if (!X.equals(A1.getText().toString()) && !O.equals(A1.getText().toString())) {
                            System.out.println("A1 was empty");
                            A1.setText(XO);
                            board[0][0] = bit;
                        }
                        break;

                    case R.id.B1:
                        if (!X.equals(B1.getText().toString()) && !O.equals(B1.getText().toString())) {
                            B1.setText(XO);
                            board[0][1] = bit;
                        }
                        break;

                    case R.id.C1:
                        if (!X.equals(C1.getText().toString()) && !O.equals(C1.getText().toString())) {
                            C1.setText(XO);
                            board[0][2] = bit;
                        }
                        break;

                    case R.id.A2:
                        if (!X.equals(A2.getText().toString()) && !O.equals(A2.getText().toString())) {
                            A2.setText(XO);
                            board[1][0] = bit;
                        }
                        break;

                    case R.id.B2:
                        if (!X.equals(B2.getText().toString()) && !O.equals(B2.getText().toString())) {
                            B2.setText(XO);
                            board[1][1] = bit;
                        }
                        break;

                    case R.id.C2:
                        if (!X.equals(C2.getText().toString()) && !O.equals(C2.getText().toString())) {
                            C2.setText(XO);
                            board[1][2] = bit;
                        }
                        break;

                    case R.id.A3:
                        if (!X.equals(A3.getText().toString()) && !O.equals(A3.getText().toString())) {
                            A3.setText(XO);
                            board[2][0] = bit;
                        }
                        break;

                    case R.id.B3:
                        if (!X.equals(B3.getText().toString()) && !O.equals(B3.getText().toString())) {
                            B3.setText(XO);
                            board[2][1] = bit;
                        }
                        break;

                    case R.id.C3:
                        if (!X.equals(C3.getText().toString()) && !O.equals(C3.getText().toString())) {
                            C3.setText(XO);
                            board[2][2] = bit;
                        }
                        break;
                }

                turn++;

                getSolution(board);

                if (turn == 9) {
                    clearBoard();
                    Toast.makeText(c,"Match Tied",Toast.LENGTH_SHORT).show();
                }

            }
        };

        A1.setOnClickListener(listener);
        A2.setOnClickListener(listener);
        A3.setOnClickListener(listener);
        B1.setOnClickListener(listener);
        B2.setOnClickListener(listener);
        B3.setOnClickListener(listener);
        C1.setOnClickListener(listener);
        C2.setOnClickListener(listener);
        C3.setOnClickListener(listener);
    }

    public void getSolution(int[][] board){

        //Check rows
        for(int i=0; i<3; i++){
            if(board[i][0]!=0 && board[i][0] == board[i][1] && board[i][1] == board[i][2]){
                if(board[i][0]==1){
                    sc2++;
                    score2.setText(String.valueOf(sc2));
                    Toast.makeText(c,"Player 2 wins!",Toast.LENGTH_SHORT).show();
                }
                if(board[i][0]==2){
                    sc1++;
                    score1.setText(String.valueOf(sc1));
                    Toast.makeText(c,"Player 1 wins!",Toast.LENGTH_SHORT).show();
                }
            clearBoard();
            return;
            }
        }

        //Check columns
        for(int i=0; i<3; i++){
            if(board[0][i]!=0 && board[0][i] == board[1][i] && board[1][i] == board[2][i]){
                if(board[0][i]==1){
                    sc2++;
                    score2.setText(String.valueOf(sc2));
                    Toast.makeText(c,"Player 2 wins!",Toast.LENGTH_SHORT).show();
                }
                if(board[0][i]==2){
                    sc1++;
                    score1.setText(String.valueOf(sc1));
                    Toast.makeText(c,"Player 1 wins!",Toast.LENGTH_SHORT).show();
                }
            clearBoard();
            return;
            }
        }

        //Check Diagonals
        if(board[0][0]!=0 && board[0][0] == board[1][1] && board[1][1]==board[2][2]){
            if(board[0][0]==1){
                sc2++;
                score2.setText(String.valueOf(sc2));
                Toast.makeText(c,"Player 2 wins!",Toast.LENGTH_SHORT).show();
            }
            if(board[0][0]==2){
                sc1++;
                score1.setText(String.valueOf(sc1));
                Toast.makeText(c,"Player 1 wins!",Toast.LENGTH_SHORT).show();
            }
            clearBoard();
            return;
        }

        else if(board[0][2]!=0 && board[0][2] == board[1][1] && board[1][1]==board[2][0]){
            if(board[0][2]==1){
                sc2++;
                score2.setText(String.valueOf(sc2));
                Toast.makeText(c,"Player 2 wins!",Toast.LENGTH_SHORT).show();
            }
            if(board[0][2]==2){
                sc1++;
                score1.setText(String.valueOf(sc1));
                Toast.makeText(c,"Player 1 wins!",Toast.LENGTH_SHORT).show();
            }
            clearBoard();
            return;
        }
    }

    public void clearBoard(){
        A1.setText(" ");
        A2.setText(" ");
        A3.setText(" ");
        B1.setText(" ");
        B2.setText(" ");
        B3.setText(" ");
        C1.setText(" ");
        C2.setText(" ");
        C3.setText(" ");
        turn=0;

        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                board[i][j]=0;
            }
        }
    }
}