package com.example.secondassignment;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText email,password;
    Button login;
    TextView signup;
    boolean register;
    String n,e,p;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        register = false;
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(register)
                {
                    if(email.getText().toString().equals(e)  && password.getText().toString().equals(p))
                    {
                        Intent i = new Intent(getApplicationContext(),MainActivity3.class);
                        i.putExtra("name",n);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    }
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Please register first", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(getApplicationContext(),MainActivity2.class);
                startActivityForResult(i,1234);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1234 && resultCode==4321  )
        {
            n = data.getStringExtra("name");
            e = data.getStringExtra("email");
            p = data.getStringExtra("password");
            Toast.makeText(this, "name = "+n+" email = "+e+" password = "+p, Toast.LENGTH_SHORT).show();
            register = true;
        }
    }
}