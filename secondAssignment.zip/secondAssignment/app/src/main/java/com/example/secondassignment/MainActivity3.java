package com.example.secondassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity
{
    TextView welcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        welcome = findViewById(R.id.welcome);
        Intent i = getIntent();

        if(i!=null)
        {
            String name = i.getStringExtra("name");
            welcome.setText("Welcome "+name);
        }
    }
}