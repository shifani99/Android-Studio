package com.example.multistepform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    ProgressBar steps;
    TextView head, conName, conEmail, conAge, conColour;
    EditText name, password, email;
    LinearLayout l1, l2, l3, l4;
    String userName, userEmail, userPswd, userAge, userColour;
    Button next1, next2, next3, back2, back3;
    RadioGroup ages, colours;
    RadioButton selectedAge, selectedColour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        steps = findViewById(R.id.steps);
        head = findViewById(R.id.head);
        l1 = findViewById(R.id.layout1);
        l2 = findViewById(R.id.layout2);
        l3 = findViewById(R.id.layout3);
        l4 = findViewById(R.id.layout4);
        name = findViewById(R.id.name);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        next1 = findViewById(R.id.next1);
        next2 = findViewById(R.id.next2);
        next3 = findViewById(R.id.next3);
        back2 = findViewById(R.id.back2);
        back3 = findViewById(R.id.back3);
        ages = findViewById(R.id.ages);
        colours = findViewById(R.id.colours);
        conName = findViewById(R.id.conName);
        conAge = findViewById(R.id.conAge);
        conEmail = findViewById(R.id.conEmail);
        conColour = findViewById(R.id.conColour);

        steps.setMax(4);
        steps.setIndeterminate(false);

        head.setText("STEP 1");

        steps.setProgress(1);

        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                Pattern em = Pattern.compile("[A-Za-z][a-zA-Z0-9._-]*@[a-z]+\\.[a-z]{2,3}");
                Matcher m = em.matcher(email.getText().toString());
                if(m.lookingAt())
                    email.setError(null);
                else
                    email.setError("Invalid email");
            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                //"Atul@321"
                Pattern em = Pattern.compile("(?=.*[A-Z]+)(?=.*[a-z]+)(?=.*[0-9]+)(?=.*[@$#]+).{6,}");
                Matcher m = em.matcher(password.getText().toString());
                if(m.lookingAt())
                    password.setError(null);
                else
                    password.setError("Password should contain atleast one capital , small , digit & symbol character");
            }
        });

        next1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userName = name.getText().toString();
                userEmail = email.getText().toString();
                userPswd = password.getText().toString();
                l1.setVisibility(View.GONE);
                head.setText("STEP 2");
                steps.incrementProgressBy(1);
            }
        });

        ages.check(R.id.age1);
        colours.check(R.id.colour1);

        back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                l1.setVisibility(View.VISIBLE);
                head.setText("STEP 1");
                steps.setProgress(1);
            }
        });

        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedAge = findViewById(ages.getCheckedRadioButtonId());
                userAge = selectedAge.getText().toString();

                selectedColour = findViewById(colours.getCheckedRadioButtonId());
                userColour = selectedColour.getText().toString();

                l2.setVisibility(View.GONE);
                head.setText("STEP 3");
                steps.incrementProgressBy(1);

                conName.setText("Name: "+userName);
                conEmail.setText("Email: "+userEmail);
                conAge.setText("Age: "+userAge);
                conColour.setText("Colour: "+userColour);
            }
        });

        back3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                l2.setVisibility(View.VISIBLE);
                head.setText("STEP 2");
                steps.setProgress(2);
            }
        });

        next3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                l3.setVisibility(View.GONE);
                head.setText("STEP 4");
                steps.incrementProgressBy(1);
            }
        });

    }
}