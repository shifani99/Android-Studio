package com.example.musicplayerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SeekBar drag;
//    Chronometer time;
    TextView time;
    int min, sec;
    Runnable r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drag = findViewById(R.id.drag);
        time = findViewById(R.id.time);

//        time.setBase(SystemClock.elapsedRealtime());
//        time.start();

//        time.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
//            @Override
//            public void onChronometerTick(Chronometer chronometer) {
//                drag.incrementProgressBy(1);
//            }
//        });

        drag.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                Toast.makeText(MainActivity.this, "onProgressChanged "+progress, Toast.LENGTH_SHORT).show()

                min=progress/60;
                sec=progress - (min * 60);

                if(sec<10){
                    time.setText(min+":0"+sec);
                }
                else{
                    time.setText(min+":"+sec);
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(MainActivity.this, "onStartTrackingTouch "+seekBar.getProgress(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(MainActivity.this, "onStopTrackingTouch "+seekBar.getProgress(), Toast.LENGTH_SHORT).show();
            }
        });

        r = new Runnable(){

            @Override
            public void run() {
                drag.incrementProgressBy(1);

                min=drag.getProgress()/60;
                sec=drag.getProgress() - (min * 60);

                if(sec<10){
                    time.setText(min+":0"+sec);
                }
                else{
                    time.setText(min+":"+sec);
                }
            }
        };

        Thread t= new Thread(){

            @Override
            public void run(){
                while(drag.getProgress()<198)
                {
                    runOnUiThread(r);
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        };

        t.start();


    }
}