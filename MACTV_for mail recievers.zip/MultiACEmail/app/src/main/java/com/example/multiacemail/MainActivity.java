package com.example.multiacemail;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

import java.util.LinkedHashSet;

public class MainActivity extends AppCompatActivity {
    MultiAutoCompleteTextView receivers;
    Button send;
    EditText body;
    String data[] = {"xyz@gmail.com","abc@gmail.com","qwe@gmail.com","asd@yahoo.com","fgh@ymail.com","jkl@outlook.com"};
    ArrayAdapter<String> adapter;
    LinkedHashSet<String> values;
    String[] emailList, sendTo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        receivers = findViewById(R.id.receivers);
        send = findViewById(R.id.send);
        body= findViewById(R.id.body);

        adapter = new ArrayAdapter<>(getApplication(),R.layout.tv_layout,R.id.textView, data);
        values = new LinkedHashSet<>();

        receivers.setAdapter(adapter);
        receivers.setThreshold(1);
        receivers.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        receivers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String v= receivers.getText().toString();
//                System.out.println("\nV: "+v);
                String[] emailList = v.split(",");

                System.out.println(emailList[emailList.length-2]);

                adapter.remove(emailList[emailList.length-2]);

                for(int i=0;i<emailList.length-1;i++){
                        values.add(emailList[i]);
                }
                if(values.size() == 6){
                    Toast.makeText(getApplicationContext(),"All email options exhausted",Toast.LENGTH_SHORT);
                }
            }
        });



        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                System.out.println("\nEMails:"+values);

                sendTo = new String[values.size()];

                int pos=0;

                for(String mail: values){
                    sendTo[pos]=mail;
                    pos++;
                }

                String mailBody = body.getText().toString();

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL, sendTo);
                intent.putExtra(Intent.EXTRA_TEXT, mailBody);
                startActivity(intent);
            }
        });

    }
}