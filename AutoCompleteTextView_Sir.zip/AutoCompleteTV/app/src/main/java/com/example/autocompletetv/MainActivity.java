package com.example.autocompletetv;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView country;
    Button submit;
    String []data = {"India","China","Japan","Africa","USA","Sri Lanka"};
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        country = findViewById(R.id.country);
        submit = findViewById(R.id.submit);

        adapter = new ArrayAdapter<>(getApplicationContext(),R.layout.actv_textview,R.id.textView,data);

        country.setAdapter(adapter);
        country.setThreshold(1);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, ""+country.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        country.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, ""+country.getText(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}