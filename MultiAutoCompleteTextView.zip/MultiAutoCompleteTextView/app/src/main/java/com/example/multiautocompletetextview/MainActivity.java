package com.example.multiautocompletetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class MainActivity extends AppCompatActivity {
    MultiAutoCompleteTextView country;
    Button submit;
    String data[] = {"India","China","Nepal","Pakistan","Africa","Malaysia"};
    ArrayAdapter<String> adapter;
    LinkedHashSet<String> values;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        country = findViewById(R.id.country);
        submit = findViewById(R.id.submit);
        values = new LinkedHashSet<>();
        adapter = new ArrayAdapter<>(getApplicationContext(),R.layout.mactv_textview,R.id.textView,data);

        country.setAdapter(adapter);
        country.setThreshold(1);
        country.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        country.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String v = country.getText().toString();
                String d[] = v.split(",");
                if(d.length==4)
                    country.setEnabled(false);
                v = "";
                for (int i = 0; i < d.length; i++) {
                    v = v + d[i];
                }
                Toast.makeText(MainActivity.this, ""+v, Toast.LENGTH_SHORT).show();
            }
        });

    }
}