package com.example.thirdassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static android.content.Intent.ACTION_VIEW;

public class Browser extends AppCompatActivity {
    EditText webaddr;
    Button go;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        webaddr = findViewById(R.id.webaddr);
        go = findViewById(R.id.go);

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = webaddr.getText().toString();
                Uri go = Uri.parse("https:"+url);
                Intent web = new Intent(ACTION_VIEW,go);
                startActivity(web);
            }
        });
    }
}