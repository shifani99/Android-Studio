package com.example.thirdassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button website,maps,gmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        website = findViewById(R.id.website);
        maps = findViewById(R.id.maps);
        gmail = findViewById(R.id.gmail);
    }

    public void buttonClick(View view)
    {
        switch(view.getId())
        {
            case R.id.gmail:
                Intent gmail = new Intent(getApplicationContext(),Gmail.class);
                startActivity(gmail);
                break;

            case R.id.maps:
                Intent maps = new Intent(getApplicationContext(),Maps.class);
                startActivity(maps);
                break;

            case R.id.website:
                Intent browser = new Intent(getApplicationContext(),Browser.class);
                startActivity(browser);
                break;
        }
    }
}