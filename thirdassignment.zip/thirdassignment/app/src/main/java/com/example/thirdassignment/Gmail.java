package com.example.thirdassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Gmail extends AppCompatActivity {
    EditText receiver,message,subject;
    Button send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gmail);

        receiver = findViewById(R.id.receiver);
        message = findViewById(R.id.message);
        send = findViewById(R.id.send);
        subject = findViewById(R.id.subject);

        send.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String to[] = {receiver.getText().toString()};
                Intent mail = new Intent(Intent.ACTION_SENDTO);
                mail.setData(Uri.parse("mailto:")); // only email apps should handle this
                mail.putExtra(Intent.EXTRA_EMAIL,to);
                mail.putExtra(Intent.EXTRA_SUBJECT,subject.getText().toString());
                mail.putExtra(Intent.EXTRA_TEXT,message.getText().toString());
                startActivity(mail);
            }
        });
    }
}