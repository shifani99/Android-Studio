package com.example.locationautocomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView country, state, city;
    Button submit;
    ArrayAdapter<String> adapter1, adapter2,adapter3;
    String[] data1 = {"Australia","Germany","India"};
    String[][] data2 ={{"New South Wales","Queensland","Western Australia","South Australia","Victoria","Tasmania"},
            {"Berlin","Bayern (Bavaria)","Niedersachsen (Lower Saxony)","Baden-Württemberg","Rheinland-Pfalz (Rhineland-Palatinate)","Sachsen (Saxony)","Thüringen (Thuringia)",
                    "Hessen","Nordrhein-Westfalen (North Rhine-Westphalia)","Sachsen-Anhalt (Saxony-Anhalt)","Brandenburg","Mecklenburg-Vorpommern","Hamburg",
                    "Schleswig-Holstein","Saarland","Bremen"},
            {"Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh",
                    "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand",
                    "West Bengal"}
    };
    String[][] data3 ={{"Sydney","Albury","Armidale","Bathurst","Blue Mountains","Broken Hill","Campbelltown","Cessnock","Dubbo","Goulburn","Grafton",
            "Lithgow","Liverpool","Newcastle","Orange","Parramatta","Penrith","Queanbeyan","Tamworth","Wagga Wagga","Wollongong"},
            {"Brisbane","Bundaberg","Caboolture","Cairns","Caloundra","Gladstone","Gold Coast","Gympie","Hervey Bay","Ipswich","Logan City","Mackay",
                    "Maryborough","Mount Isa","Rockhampton","Sunshine Coast","Toowoomba","Townsville"},
            {"Perth","Albany","Bunbury","Busselton","Fremantle","Geraldton","Joondalup","Kalgoorlie","Karratha","Mandurah","Rockingham"},
            {"Adelaide","Mount Barker","Mount Gambier","Murray Bridge","Port Adelaide","Port Augusta","Port Pirie","Port Lincoln","Victor Harbor","Whyalla"},
            {"Melbourne","Ararat","Bairnsdale","Benalla","Ballarat","Bendigo","Dandenong","Frankston","Geelong","Hamilton","Horsham","Latrobe City","Melton","Mildura","Sale",
                    "Shepparton","Swan Hill","Wangaratta","Warrnambool","Wodonga"},
            {"Hobart","Burnie","Devonport","Launceston"},
            {"Berlin"},
            {"Munich","Nuremberg","Augsburg","Regensburg"," Ingolstadt","Würzburg","Fürth","Erlangen"},
            {"Hanover","Braunschweig","Oldenburg","Osnabrück","Wolfsburg","Göttingen","Hildesheim"},
            {"Stuttgart","Karlsruhe","Mannheim","Freiburg im Breisgau","Heidelberg","Ulm","Heilbronn","Pforzheim","Reutlingen"},
            {"Mainz","Ludwigshafen am Rhein","Trier","Koblenz"},
            {"Leipzig","Dresden","Chemnitz"},
            {"Erfurt","Jena"},
            {"Frankfurt am Main","Wiesbaden","Kassel","Darmstadt","Offenbach am Main"},
            {"Cologne","Düsseldorf","Dortmund","Essen","Duisburg","Bochum","Wuppertal","Bielefeld","Bonn","Münster","Gelsenkirchen","Mönchengladbach","Aachen","Krefeld",
                    "Oberhausen","Hagen","Hamm","Mülheim an der Ruhr","Leverkusen","Solingen","Herne","Neuss","Paderborn","Bottrop","Recklinghausen","Bergisch Gladbach","Remscheid",
            "Moers","Siegen"},
            {"Halle (Saale)","Magdeburg"},
            {"Potsdam"},
            {"Rostock"},
            {"Hamburg"},
            {"Kiel","Lübeck"},
            {"Saarbrücken"},
            {"Bremen","Bremerhaven"},
            {"Adoni","Amaravati","Anantapur","Bhimavaram","Chilakaluripet","Chittoor","Dharmavaram","Eluru","Gudivada","Guntakal","Guntur","Hindupur","Kadapa","Kakinada","Kurnool",
                    "Machilipatnam","Madanapalle","Nandyal","Narasaraopet","Nellore","Ongole","Palakollu","Proddatur","Rajahmundry","Srikakulam","Tadepalligudem","Tadipatri","Tenali",
                    "Tirupati","Vijayawada","Visakhapatnam","Vizianagaram"},
            {"Along","Basar","Bomdila","Itanagar","Khonsa","Margherita","Naharlagun","Pasighat","Tawang","Tezu","Ziro"},
            {"Guwahati","Silchar","Dibrugarh","Jorhat","Nagaon","Bongaigaon","Tinsukia","Tezpur"},
            {"Arrah","Aurangabad","Bagaha","Begusarai","Bettiah","Bhagalpur","Bihar Sharif","Buxar","Chhapra","Danapur","Darbhanga","Dehri","Gaya","Hajipur","Jamalpur","Jehanabad",
                    "Katihar","Kishanganj","Motihari","Munger","Muzaffarpur","Nawada","Patna","Purnia","Saharsa","Sasaram","Sitamarhi","Siwan"},
            {"Ambikapur","Bhilai","Bilaspur","Chirmiri","Dhamtari","Jagdalpur","Korba","Mahasamund","Raigarh","Raipur","Rajnandgaon"},
            {"Panaji","Madgaon","Mormugao","Mapuca","Curchorem Cacora","Ponda","Sancoale"},
            {"Ahmedabad","Anand","Bharuch","Bhavnagar","Gandhidham","Jamnagar","Junagadh","Morbi","Nadiad","Navsari","Porbandar","Rajkot","Surat","Surendranagar","Vadodara"},
            {"Ambala","Bahadurgarh","Bhiwani","Faridabad","Gurugram","Hisar","Jind","Kaithal","Karnal","Kosli","Palwal","Panchkula","Panipat","Pundri","Rewari","Rohtak","Sirsa",
                    "Sonipat","Thanesar","Yamunanagar"},
            {"Chamba","Dalhousie","Dharamshala","Kangra","Kasauli","Kullu","Manali","Shimla","Solan"},
            {"Bokaro Steel City","Chirkunda","Deoghar","Dhanbad","Giridih","Hazaribagh","Jamshedpur","Medininagar","Phusro","Ramgarh","Ranchi"},
            {"Bagalkot","Bangalore","Belgaum","Bellary","Bhadravati","Bidar","Bijapur","Chikmagalur","Chitradurga","Davanagere","Gadag-Betageri","Gangavati","Gulbarga","Hassan",
                    "Hospet","Hubli","Hubli–Dharwad","Kolar","Mandya","Mangalore","Mysore","Raichur","Ranebennuru","Robertsonpet","Shimoga","Tumkur","Udupi"},
            {"Alappuzha","Alleppey","Alwaye","Bekal","Fort Kochi","Kochi","Kollam","Thrissur","Ernakulam","Kottayam","Kovalam","Kozikode","Kumarakom","Malampuzha","Munnar",
                    "Palakkad","Pathanamthitta","Thoppumpaddy","Ponnani","Punalur","Thalassery","Thekkady","Thiruvananthapuram","Thrippunithura","Tirur","Varkala","Perinthalamanna"},
            {"Gwalior","Bhopal","Jabalpur","Indore","Rewa","Katni","Satna","Sagar","Ujjain"},
            {"Achalpur","Ahmednagar","Akola","Amravati","Aurangabad","Barshi","Beed","Bhiwandi-Nizampur","Bhusawal","Chandrapur","Dhule","Gondia","Mumbai","Hinganghat",
                    "Ichalkaranji","Jalgaon","Jalna","Kamptee","Kolhapur","Latur","Malegaon","Miraj","Nagpur","Nanded-Waghela","Nandurbar","Nashik","Navi Mumbai", "Osmanabad",
                    "Panvel","Parbhani","Pune","Sangli","Satara","Solapur","Thane","Udgir","Wardha","Yavatmal"},
            {"Churachandpur","Imphal","Kakching","Mayang Imphal","Moirang","Phek","Thoubal","Wangjing","Yairipok"},
            {"Baghmara","Resubelpara","Shillong","Williamnagar","Jowai","Tura"},
            {"Aizawl","Darlawn","Khawhai","Kolasib","Lunglei","Mamit","North Vanlaiphai","Saiha","Sairang","Saitlaw","Serchhip","Thenzawl"},
            {"Dimapur","Kohima","Mokokchung"},
            {"Bhubaneswar","Brahmapur","Jharsuguda","Puri","Rourkela"},
            {"Ludhiana","Bathinda","Hoshiarpur","Abohar","Khanna","Phagwara","Muktasar","Barnala","Rajpura","Firozpur","Kapurthala","Sunam","Amritsar","Jalandhar"},
            {"Jaipur","Jodhpur","Kota","Bikaner","Ajmer","Udaipur","Bhilwara","Alwar"},
            {"Gangtok"},
            {"Chennai","Coimbatore","Ooty","Tiruchchirapalli","Madurai","Salem","Thanjavur","Kanyakumari","Vellore"},
            {"Hyderabad","Warangal","Nizamabad","Khammam","Karimnagar","Ramagundam","Mahabubnagar","Nalgonda","Adilabad","Suryapet","Miryalaguda"},
            {"Agartala"},
            {"Agra","Akbarpur, Ambedkar Nagar","Aligarh","Allahabad","Amroha","Azamgarh","Bahraich","Ballia","Banda","Baraut","Bareilly","Basti","Budaun","Bulandshahr",
                    "Chandausi","Deoria","Etah","Etawah","Faizabad","Farrukhabad","Fatehpur","Ghazipur","Gonda","Gorakhpur","Greater Noida","Hapur","Hardoi","Jaunpur","Kanpur",
                    "Kasganj","Khatik Mohalla (Mathura Cantt)","Khurja","Lakhimpur","Lalitpur","Loni","Lucknow","Mainpuri","Mathura","Mau","Meerut","Mirzapur","Modinagar",
                    "Moradabad","Muzaffarnagar","Noida","Orai","Pilibhit","Raebareli","Rampur","Saharanpur","Sambhal","Shahjahanpur","Shamli","Shikohabad","Sitapur","Sultanpur",
                    "Unnao","Varanasi"},
            {"Dehradun","Haldwani","Haridwar","Kashipur, Uttarakhand","Rishikesh","Roorkee","Rudrapur"},
            {"Kolkata","Asansol","Siliguri","Durgapur","Bardhaman","English Bazar","Baharampur","Habra","Kharagpur","Shantipur","Dankuni","Dhulian","Ranaghat","Haldia"}
    };

    int countryPos, statePos, cityPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        country = findViewById(R.id.country);
        state = findViewById(R.id.state);
        city = findViewById(R.id.city);
        submit = findViewById(R.id.submit);

//        adapter = new ArrayAdapter<>(getApplicationContext(),R.layout.actv_textview,R.id.textView,data);
        adapter1 = new ArrayAdapter<>(getApplicationContext(),R.layout.dropdown_tv,R.id.textView,data1);
        country.setAdapter(adapter1);
        country.setThreshold(1);

//        adapter2 = new ArrayAdapter<>(getApplicationContext(),R.layout.dropdown_tv,R.id.textView,data2);
//        adapter3 = new ArrayAdapter<>(getApplicationContext(),R.layout.dropdown_tv,R.id.textView,data3);

        country.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                countryPos = Arrays.asList(data1).indexOf(country.getText().toString());
//                System.out.println("\nCountry position:"+countryPos+" "+id);
                adapter2 = new ArrayAdapter<>(getApplicationContext(),R.layout.dropdown_tv,R.id.textView,data2[countryPos]);
                state.setAdapter(adapter2);
                state.setThreshold(1);
            }
        });

        state.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                statePos = Arrays.asList(data2[countryPos]).indexOf(state.getText().toString());
//                System.out.println("\nState position:"+statePos+" "+id);

                int startPos=0;

                for(int i=0;i<countryPos;i++){
                    startPos+=data2[i].length;
                }

                cityPos = startPos + statePos;

                adapter3 = new ArrayAdapter<>(getApplicationContext(),R.layout.dropdown_tv,R.id.textView,data3[cityPos]);
                city.setAdapter(adapter3);
                city.setThreshold(1);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),city.getText().toString()+", "+state.getText().toString()+", "+country.getText().toString(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}