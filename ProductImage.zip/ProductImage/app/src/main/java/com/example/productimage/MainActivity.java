package com.example.productimage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    ImageButton img1, img2, img3;
    ImageSwitcher productView;
    HashMap <Integer,Integer> products;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
        productView = findViewById(R.id.productView);

        img1.setImageResource(R.drawable.pic1);
        img2.setImageResource(R.drawable.pic2);
        img3.setImageResource(R.drawable.pic3);

        products=new HashMap<>();

        products.put(R.id.img1,R.drawable.pic1);
        products.put(R.id.img2,R.drawable.pic2);
        products.put(R.id.img3,R.drawable.pic3);

        productView.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView image = new ImageView(getApplicationContext());
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                image.setLayoutParams(new ImageSwitcher.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));
                return image;
            }
        });

        productView.setImageResource(R.drawable.pic1);

        Animation in = AnimationUtils.loadAnimation(getApplicationContext(),android.R.anim.fade_in);
        Animation out = AnimationUtils.loadAnimation(getApplicationContext(),android.R.anim.fade_out);

        productView.setInAnimation(in);
        productView.setOutAnimation(out);
    }

    public void onButtonClick(View v){
        System.out.println("\nID: "+v.getId());
        productView.setImageResource(products.get(v.getId()));
    }
}