package com.example.ratingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RatingBar rating;
    ImageView smiley;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rating = findViewById(R.id.ratingBar);
        smiley = (ImageView) findViewById(R.id.smiley);

        rating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                int n = (int) rating;
                switch(n){
                    case 0:
                        smiley.setImageDrawable(getResources().getDrawable(R.drawable.cry));
                        break;

                    case 1:
                        smiley.setImageDrawable(getResources().getDrawable(R.drawable.super_sad));
                        break;

                    case 2:
                        smiley.setImageDrawable(getResources().getDrawable(R.drawable.sad));
                        break;

                    case 3:
                        smiley.setImageDrawable(getResources().getDrawable(R.drawable.okay));
                        break;

                    case 4:
                        smiley.setImageDrawable(getResources().getDrawable(R.drawable.happy));
                        break;

                    case 5:
                        smiley.setImageDrawable(getResources().getDrawable(R.drawable.super_happy));
                        break;
                }
            }
        });
    }
}