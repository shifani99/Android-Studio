package com.example.typingtestapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    TextView original, answer, accuracy, wpm, correctCount, incorrectCount;
    String sentence, input;
    float correct,  noOfWords, noOfTyped, acc, wordsPM;
    int correctWords;
    long time, min, sec;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        original = findViewById(R.id.original);
        answer = findViewById(R.id.answer);
        accuracy = findViewById(R.id.accuracy);
        wpm = findViewById(R.id.wpm);
        back = findViewById(R.id.back);
        correctCount = findViewById(R.id.correctWords);
        incorrectCount = findViewById(R.id.incorrectWords);

        Intent intent =getIntent();

        time = intent.getLongExtra("time",10);

        System.out.println("\nTime: "+time);

        sentence = intent.getStringExtra("sentence");
        input = intent.getStringExtra("answer");

        String[] words=sentence.split(" ");
        String[] typedWords=input.split(" ");

        noOfWords=words.length;
        noOfTyped=typedWords.length;
        correct = 0;
        correctWords = 0;

        if(input.length()>0){
            for(int i=0;i<words.length&&i<typedWords.length;i++){
                if(words[i].equals(typedWords[i])){
                    correct++;
                    correctWords++;
                }
                else{
                    int diff=words[i].compareTo(typedWords[i]);
                    if(diff>0){
                        if(diff<5)
                            correct+=0.5;
                        else if(diff<10)
                            correct+=0.25;
                    }
                    else{
                        if(diff>-5)
                            correct+=0.5;
                        else if(diff>-10)
                            correct+=0.25;
                    }
                }
            }
        }
        else{
            acc = (float)0;
            noOfTyped = (float)0;
        }


        acc=(correct/noOfWords)*100;

        min = time/60000;
        sec = (time -  min*60000)/1000 ;

        if(min<1){
            noOfTyped = noOfTyped * (60/sec);
            min=1;

        }


        wordsPM = (float)(noOfTyped/min);

        original.setText(sentence);
        answer.setText(input);

        correctCount.setText(String.valueOf(correctWords));
        incorrectCount.setText(String.valueOf((int)(noOfWords-correctWords)));

        accuracy.setText(acc+"%");
        wpm.setText(wordsPM+"WPM");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}