package com.example.typingtestapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView test;
    EditText answer;
    Chronometer timer;
    Button done;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        test = findViewById(R.id.test);
        answer = findViewById(R.id.answer);
        timer = findViewById(R.id.timer);
        done = findViewById(R.id.done);

        intent = new Intent(getApplicationContext(),ResultActivity.class);

        timer.setBase(SystemClock.elapsedRealtime());
        timer.start();

        answer.addTextChangedListener(new TextWatcher()
        {
            @Override   // 6    4
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(count>after)
                    answer.setText(s);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long time = SystemClock.elapsedRealtime()-timer.getBase();
                intent.putExtra("sentence",test.getText().toString());
                intent.putExtra("answer",answer.getText().toString());
                intent.putExtra("time",time);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        answer.setText("");
        timer.setBase(SystemClock.elapsedRealtime());
    }
}