package com.example.fifthassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ImageView img1,img2,img3,img4,img5,img6,img7,img8,img9;
    ArrayList<Integer> images;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        images = new ArrayList<>();
        images.add(R.drawable.dhoni);
        images.add(R.drawable.dinesh);
        images.add(R.drawable.jadeja);
        images.add(R.drawable.mayank);
        images.add(R.drawable.pandya);
        images.add(R.drawable.pant);
        images.add(R.drawable.rahul);
        images.add(R.drawable.rohit);
        images.add(R.drawable.virat);

        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
        img4 = findViewById(R.id.img4);
        img5 = findViewById(R.id.img5);
        img6 = findViewById(R.id.img6);
        img7 = findViewById(R.id.img7);
        img8 = findViewById(R.id.img8);
        img9 = findViewById(R.id.img9);

        img1.setImageResource(R.drawable.dhoni);
        img2.setImageResource(R.drawable.dinesh);
        img3.setImageResource(R.drawable.jadeja);
        img4.setImageResource(R.drawable.mayank);
        img5.setImageResource(R.drawable.pandya);
        img6.setImageResource(R.drawable.pant);
        img7.setImageResource(R.drawable.rahul);
        img8.setImageResource(R.drawable.rohit);
        img9.setImageResource(R.drawable.virat);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),MainActivity2.class);
                int position=0;
                switch (v.getId())
                {
                    case R.id.img1:
                        position=0;
                        break;
                    case R.id.img2:
                        position=1;
                        break;
                    case R.id.img3:
                        position=2;
                        break;
                    case R.id.img4:
                        position=3;
                        break;
                    case R.id.img5:
                        position=4;
                        break;
                    case R.id.img6:
                        position=5;
                        break;
                    case R.id.img7:
                        position=6;
                        break;
                    case R.id.img8:
                        position=7;
                        break;
                    case R.id.img9:
                        position=8;
                        break;

                }
                i.putExtra("image",images.get(position));
                startActivity(i);
            }
        };

        img1.setOnClickListener(listener);
        img2.setOnClickListener(listener);
        img3.setOnClickListener(listener);
        img4.setOnClickListener(listener);
        img5.setOnClickListener(listener);
        img6.setOnClickListener(listener);
        img7.setOnClickListener(listener);
        img8.setOnClickListener(listener);
        img9.setOnClickListener(listener);
    }
}