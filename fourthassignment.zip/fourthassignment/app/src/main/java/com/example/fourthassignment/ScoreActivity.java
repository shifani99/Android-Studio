package com.example.fourthassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class ScoreActivity extends AppCompatActivity {
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        result = findViewById(R.id.score);

        Intent score  = getIntent();
        if(score!=null)
        {
            int correctAnswers = score.getIntExtra("score",-1);
            int outof = score.getIntExtra("outof",-1);
            result.setText("Correct answers "+correctAnswers+" / "+outof);
        }
    }
}