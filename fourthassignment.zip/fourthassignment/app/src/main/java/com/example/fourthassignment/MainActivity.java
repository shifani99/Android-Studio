package com.example.fourthassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity
{

    ArrayList<Question> question;
    int questionPosition;
    TextView quest,time;
    RadioButton opt1,opt2,opt3,opt4;
    Button next,prev,submit;
    CountDownTimer timer;
    HashMap<Integer,String> userInput;
    String ans;
    int correctAnswers;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userInput = new HashMap<>();
        next = findViewById(R.id.next);
        quest = findViewById(R.id.question);
        opt1 = findViewById(R.id.option1);
        opt2 = findViewById(R.id.option2);
        opt3 = findViewById(R.id.option3);
        opt4 = findViewById(R.id.option4);
        time = findViewById(R.id.time);
        prev = findViewById(R.id.prev);
        submit = findViewById(R.id.submit);
        question = new ArrayList<>();

        timer = new CountDownTimer(120000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long sec = millisUntilFinished/1000;
                long min = sec/60;
                sec = sec%60;
                time.setText(min+":"+sec);
            }

            @Override
            public void onFinish() {
                time.setText("0:0");
                Toast.makeText(MainActivity.this, "Time Finished", Toast.LENGTH_SHORT).show();

                calculateScore();

                Intent score = new Intent(getApplicationContext(),ScoreActivity.class);
                score.putExtra("score",correctAnswers);
                score.putExtra("outof",question.size());
                score.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(score);
            }
        };

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();
                calculateScore();
                Intent score = new Intent(getApplicationContext(),ScoreActivity.class);
                score.putExtra("score",correctAnswers);
                score.putExtra("outof",question.size());
                score.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(score);
            }
        });

        addQuestion();
        questionPosition =  0;
        displayQuestion(questionPosition);
        timer.start();
    }

    public void changeQuestion(View view)
    {
        switch (view.getId())
        {
            case R.id.next:
                questionPosition++;
                break;
            case R.id.prev:
                questionPosition--;
                break;
        }

        if(questionPosition>0)
            prev.setVisibility(View.VISIBLE);
        else
            prev.setVisibility(View.INVISIBLE);

        if(questionPosition==question.size()-1)
            next.setVisibility(View.INVISIBLE);

        if(questionPosition<question.size()-1)
            next.setVisibility(View.VISIBLE);

        displayQuestion(questionPosition);

        displayAnswer();
    }

    public void onRadioClick(View view)
    {

        switch (view.getId())
        {
            case R.id.option1:
                ans = opt1.getText().toString();
                storeAnswer();
                setBackground(1);
                break;
            case R.id.option2:
                ans = opt2.getText().toString();
                storeAnswer();
                setBackground(2);
                break;
            case R.id.option3:
                ans = opt3.getText().toString();
                storeAnswer();
                setBackground(3);
                break;
            case R.id.option4:
                ans = opt4.getText().toString();
                storeAnswer();
                setBackground(4);
                break;
        }

    }

    public void displayQuestion(int position)
    {
        quest.setText(question.get(position).getQuestion());
        opt1.setText(question.get(position).getOption1());
        opt2.setText(question.get(position).getOption2());
        opt3.setText(question.get(position).getOption3());
        opt4.setText(question.get(position).getOption4());
    }

    public void addQuestion()
    {
        question.add(new Question("What is Java ","Software","City","Programming Language","Planet","Programming Language"));
        question.add(new Question("Which of the following option leads to the portability and security of Java","Bytecode is executed by JVM","The applet makes the Java code secure and portable","Use of exception handling","Dynamic binding between objects","Bytecode is executed by JVM"));
        question.add(new Question("Which of the following is not a Java feature","Dynamic","Architecture Neutral","Use of pointers","Object-oriented","Use of pointers"));
        question.add(new Question("What is the return type of the hashCode() method in the Object class","Object","int","long","void","int"));
    }

    public void storeAnswer()
    {
        userInput.put(questionPosition,ans);
    }

    public void displayAnswer()
    {
        String answer = userInput.get(questionPosition);
        if(answer!=null)
        {
            if(opt1.getText().toString().equals(answer)) {
                opt1.setChecked(true);
                setBackground(1);
            }
            else if(opt2.getText().toString().equals(answer)) {
                opt2.setChecked(true);
                setBackground(2);
            }
            else if(opt3.getText().toString().equals(answer)) {
                opt3.setChecked(true);
                setBackground(3);
            }
            else if(opt4.getText().toString().equals(answer)) {
                opt4.setChecked(true);
                setBackground(4);
            }
        }
        else
        {
            resetBackground();
            opt1.setChecked(false);
            opt2.setChecked(false);
            opt3.setChecked(false);
            opt4.setChecked(false);
        }
    }

    public void setBackground(int radioPosition)//position of option
    {
        resetBackground();
        if(radioPosition==1)
            opt1.setBackgroundColor(Color.CYAN);
        else if(radioPosition==2)
            opt2.setBackgroundColor(Color.CYAN);
        else if(radioPosition==3)
            opt3.setBackgroundColor(Color.CYAN);
        else if(radioPosition==4)
            opt4.setBackgroundColor(Color.CYAN);
    }

    public void resetBackground()
    {
        opt1.setBackgroundColor(Color.TRANSPARENT);
        opt2.setBackgroundColor(Color.TRANSPARENT);
        opt3.setBackgroundColor(Color.TRANSPARENT);
        opt4.setBackgroundColor(Color.TRANSPARENT);
    }

    public void calculateScore()
    {
        for (Map.Entry<Integer,String> entry:userInput.entrySet())
        {
            int position = entry.getKey();
            String answer = entry.getValue();
            Question quest = question.get(position);
            if(quest.getAnswer().equals(answer))
            {
                correctAnswers++;
            }
        }
    }

}
